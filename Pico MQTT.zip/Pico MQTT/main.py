from machine import Pin, SPI, I2C
import time, network
from ST7735 import TFT
from sysfont import sysfont
from sht4x import SHT4X
from umqtt.simple import MQTTClient

# --- Display Setup (SPI0) ---
spi = SPI(0, baudrate=20_000_000, polarity=0, phase=0,
          sck=Pin(18), mosi=Pin(19), miso=None)
tft = TFT(spi, 21, 20, 22)  # dc=21, rst=20, cs=22
tft.rgb(True)
tft.init_7735(tft.GREENTAB80x160)

# --- LED Setup ---
led = Pin(27, Pin.OUT)
led.value(0)

# --- Sensor Setup (I2C1) ---
i2c = I2C(1, sda=Pin(2), scl=Pin(3), freq=100_000)
sht = SHT4X(i2c)


# --- Welcome Screen ---
tft.fill(TFT.BLACK)
tft.text((10, 0), 'MQTT TEST', TFT.RED, sysfont, 2)
tft.text((10, 30), 'by Ceyhun', TFT.GREEN, sysfont, 2)
tft.text((10, 60), '2025', TFT.BLUE, sysfont, 2)
time.sleep(2)

# --- Wi‑Fi + MQTT Config ---
SSID = 'wifi-id'
PASS = 'password'
MQTT_BROKER = 'broker.hivemq.com'
CLIENT_ID = 'PicoW_MQTT_Client'
TOPIC_PUB = b'CeyhunPico'
TOPIC_SUB = b'CEYHUN'

# --- MQTT Callback ---
def mqtt_cb(topic, msg):
    cmd = msg.decode().strip().upper()
    print('CMD recv:', cmd)
    tft.fill(TFT.BLACK)
    tft.text((10, 0), 'COMMAND', TFT.RED, sysfont, 2)
    tft.text((10, 30), cmd, TFT.GREEN, sysfont, 2)
    if cmd == 'LED ON':
        led.value(1)
    elif cmd == 'LED OFF':
        led.value(0)

# --- Connect to Wi‑Fi ---
def wifi_connect():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(SSID, PASS)
    while not wlan.isconnected():
        print('Connecting to WiFi...')
        time.sleep(1)
    print('WiFi connected:', wlan.ifconfig())

# --- Init Sequence ---
wifi_connect()
client = MQTTClient(CLIENT_ID, MQTT_BROKER)
client.set_callback(mqtt_cb)
client.connect()
client.subscribe(TOPIC_SUB)
print('MQTT connected & subscribed')


# --- Main Loop ---
while True:
    try:
        client.check_msg()  # handle incoming MQTT

        # Read sensor data
        temp = sht.temperature
        hum = sht.relative_humidity
        payload = '{{"temperature":{:.2f},"humidity":{:.2f}}}'.format(temp, hum)
        client.publish(TOPIC_PUB, payload)
        print('Published →', payload)

        # Show TEMP
        tft.fill(TFT.BLACK)
        tft.text((10, 0), 'TEMPERATURE', TFT.RED, sysfont, 2)
        tft.text((10, 30), '{:.2f} C'.format(temp), TFT.GREEN, sysfont, 2)
        time.sleep(2)

        # Show HUM
        tft.fill(TFT.BLACK)
        tft.text((10, 0), 'HUMIDITY', TFT.RED, sysfont, 2)
        tft.text((10, 30), '{:.2f} %'.format(hum), TFT.GREEN, sysfont, 2)
        time.sleep(2)

    except Exception as e:
        print('Error:', e)
        tft.fill(TFT.BLACK)
        tft.text((10, 30), 'Error', TFT.RED, sysfont, 2)
        time.sleep(2)




